#include "RD.h"

#include <Modules/ModuleManager.h>

#define LOCTEXT_NAMESPACE "RD"

DEFINE_LOG_CATEGORY(FLogRDModule);

IMPLEMENT_MODULE(FRDModule, RD);